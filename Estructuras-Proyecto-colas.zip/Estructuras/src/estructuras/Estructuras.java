/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package estructuras;
import estructuras.Logica.Log_in_Logica;
import estructuras.Logica.RutinaM;
/**
 *
 * @author Caoba
 */
public class Estructuras {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        
        RutinaM m = new RutinaM();
        m.probarMesas();
        m.probarCola();
        m.probarPila();
    } 
    
}
